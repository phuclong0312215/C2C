﻿import { Component } from '@angular/core';
import { LoginModel } from '../login/Login.Model';
import { LoginServices } from '../login/login.services';
import { NgProgressService } from "ng2-progressbar";
import { Router } from '@angular/router'
@Component({
    selector: 'login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css'],
    providers: [LoginServices]
})
export class LoginComponent {
    constructor(private pService: NgProgressService, private _Route: Router, private _LoginService: LoginServices) {
        //if (window.localStorage) {
        //    // localStorage can be used
        //    alert('a');
        //} else {
        //    alert('b');
        //    // can't be used
        //}
        
        //localStorage.removeItem('userAdmin');
    }
    LoginModel: LoginModel = new LoginModel();
    response: any;
    status: boolean = false;
    onLogin() {
      
        this.pService.start();
        var loginModel = this.LoginModel;
        this._LoginService.loginUser(loginModel).subscribe
            (data => {
                this.response = data;
                if (this.response.UserTypeID == "0") {
                    alert("Invalid Username and Password");
                    this._Route.navigate(['Login']);

                }
                else {
                    if (this.response.UserTypeID == "2") {
                        alert("Logged in Successfully");
                        location.href = '/project';
                        
                    }
                    else {
                        alert("Logged in Successfully");
                        this._Route.navigate(['admindashboard']);
                    }
                }
                this.pService.done();
            },
            err => {
                if (err)
                    alert("An Error has occured please try again after some time !");
            });

       
    }
}
