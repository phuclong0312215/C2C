﻿import { Component } from '@angular/core';

@Component({
    selector: 'admin',
    templateUrl: './admindashboard.component.html'
})
export class AdminComponent {
}
