﻿import { Component, Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
@Injectable()
export class AuthGuardAdmin implements CanActivate {

    constructor(private router: Router) { }

    canActivate() {
       // return true;
        if (localStorage.getItem('AdminUser')) {
            // logged in so return true
            return true;
        }

        //// not logged in so redirect to login page
        //this.router.navigate(['/Login']);
        return true;
    }
}