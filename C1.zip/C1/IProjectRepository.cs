﻿using System;
using System.Collections.Generic;
using System.Text;
using C2CProject.Model;
namespace C2CProject.Interface
{
    public interface IProjectRepository
    {
        void insert(ProjectItem item);
        bool isExists(int P_ID);
        void delete(int P_ID);
        List<ProjectItem> list();
        ProjectItem byId(int P_ID);
    }
}
