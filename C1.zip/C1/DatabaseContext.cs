﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;
using C2CProject.Model;
namespace C2CProject.Context
{
    public class DatabaseContext: DbContext
    {
        public DatabaseContext(DbContextOptions<DatabaseContext> options) : base(options)
        {

        }
        public DbSet<UserItem> Users { get; set; }
        public DbSet<UserTypeItem> UserType { get; set; }
        public DbSet<TokenItem> Token { get; set; }
        public DbSet<ProjectItem> Projects { get; set; }
    }
}
