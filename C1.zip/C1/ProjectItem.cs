﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace C2CProject.Model
{
    [Table("Projects")]
    public class ProjectItem
    {
        [Key]
        public int P_ID { get; set; }
        public string Title { get; set; }
        public string Location { get; set; }
        public string Designer { get; set; }
        public string Scope { get; set; }
        public string Awards { get; set; }
        public string Images { get; set; }
        public string Type { get; set; }
        public int UserId { get; set; }
        public int IsDelete { get; set; }
        public int IsActive { get; set; }
        public DateTime CreatedOn { get; set; }
        public DateTime UpdateOn { get; set; }
       
    }
}
