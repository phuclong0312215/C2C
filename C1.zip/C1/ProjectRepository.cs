﻿using C2CProject.Context;
using System;
using System.Collections.Generic;
using System.Text;
using C2CProject.Interface;
using C2CProject.Model;
using System.Linq;
namespace C2CProject.Repository
{
    public class ProjectRepository: IProjectRepository
    {
        private readonly DatabaseContext _context;
        public ProjectRepository(DatabaseContext context)
        {
            _context = context;
        }

        public ProjectItem byId(int P_ID)
        {
            throw new NotImplementedException();
        }

        public void delete(int P_ID)
        {
            throw new NotImplementedException();
        }

        public void insert(ProjectItem item)
        {
            throw new NotImplementedException();
        }

        public bool isExists(int P_ID)
        {
            throw new NotImplementedException();
        }

        public List<ProjectItem> list()
        {
            var projects = _context.Projects.ToList();
            return projects;
        }
    }
}
