﻿import { Component,OnInit } from '@angular/core';
import { ProjectModel } from './project.model';
import { ProjectServices } from './project.services';
import { NgProgressService } from 'ng2-progressbar';

@Component({
    selector: 'project',
    templateUrl: './project.component.html',
    providers: [ProjectServices]
})
export class ProjectComponent implements OnInit {
    projectData: ProjectModel[] = [];
    constructor(private pService: NgProgressService, private _projectService: ProjectServices) {
       
    }
  
    ngOnInit(): void {
        this.pService.start();
      
        this._projectService.list().subscribe(data => {
            this.projectData = data;
            this.pService.done();
        },
            error => {
                if (error) {
                    alert("An Error has occured please try again after some time !");
                }
            }
        );
    }
}
