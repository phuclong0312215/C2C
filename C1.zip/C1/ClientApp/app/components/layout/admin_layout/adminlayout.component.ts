﻿import { Component } from '@angular/core'
@Component({
    selector: 'admin-layout',
    templateUrl: './adminlayout.component.html'
})
export class AdminLayoutComponent {
}