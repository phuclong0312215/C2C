﻿import { Component } from '@angular/core'
@Component({
    selector: 'admin-sidebar',
    templateUrl: './sidebarlayout.component.html'
})
export class AdminSidebarComponent {
}