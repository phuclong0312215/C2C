﻿export class LoginModel {
    public UserName: string = "";
    public Password: string = "";

}
