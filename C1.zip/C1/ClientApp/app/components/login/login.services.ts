﻿import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { LoginModel } from '../login/login.model';
import { AppSetting } from '../app/app.setting';
@Injectable()
export class LoginServices {
    public token: string = "";
    constructor(private _http: Http, private _Route: Router) {
    }
    loginUser(loginModel: LoginModel) {
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
       
        return this._http.post(AppSetting.URL_LOGIN, loginModel, options).
            map((response: Response) => {
                let webreposnse = response.json() && response.json();
                if (webreposnse != null) {

                    localStorage.setItem('userAdmin', JSON.stringify({ username: loginModel.UserName, token: webreposnse.Token }));
                   
                    // return true to indicate successful login
                    return webreposnse;
                } else {
                    // return false to indicate failed login
                    return null;
                }

            }).catch(response => {
                if (response.status === 401) {
                    this._Route.navigate(['Login']);
                }
                return response;
            });

       
    }
}