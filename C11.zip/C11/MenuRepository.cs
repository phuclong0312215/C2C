﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C2CProject.Repository
{
    class MenuRepository
    {
    }
}
