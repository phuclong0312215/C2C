﻿using System;
using System.Collections.Generic;
using System.Text;
using C2CProject.Model;
namespace C2CProject.Interface
{
    public interface IMenu
    {
        void insert(MenuItem item);
        bool isExists(int M_ID);
        void delete(int M_ID);
        List<MenuItem> list();
        MenuItem byId(int M_ID);
    }
}
