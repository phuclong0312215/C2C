﻿using System;
using System.Collections.Generic;
using System.Text;
using C2CProject.Model;
namespace C2CProject.Interface
{
    public interface IContact
    {
        void insert(ContactItem item);
        bool isExists(int C_ID);
        void delete(int C_ID);
        List<ContactItem> list();
        ContactItem byId(int C_ID);
    }
}
