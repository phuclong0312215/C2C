﻿using C2CProject.Context;
using System;
using System.Collections.Generic;
using System.Text;
using C2CProject.Interface;
using C2CProject.Model;
using System.Linq;
namespace C2CProject.Repository
{
    public class ContactRepository : IContact
    {
        public ContactItem byId(int C_ID)
        {
            throw new NotImplementedException();
        }

        public void delete(int C_ID)
        {
            throw new NotImplementedException();
        }

        public void insert(ContactItem item)
        {
            throw new NotImplementedException();
        }

        public bool isExists(int C_ID)
        {
            throw new NotImplementedException();
        }

        public List<ContactItem> list()
        {
            throw new NotImplementedException();
        }
    }
}
