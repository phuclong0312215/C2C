﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace C2CProject.Model
{
    [Table("Contacts")]
    public class ContactItem
    {
        [Key]
        public int C_Id { get; set; }
        public string BrandName { get; set; }
        public string Type { get; set; }
        public string Address  { get; set; }
        public string City { get; set; }
        public string ZipCode { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }
        public string Images { get; set; }
        public int UserId { get; set; }
        public int IsDelete { get; set; }
        public int IsActive { get; set; }
        public DateTime CreatedOn { get; set; }
        public DateTime UpdateOn { get; set; }

    }
}
