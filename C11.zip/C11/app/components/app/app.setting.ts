﻿
export class AppSetting {
  //  public static URL = "http://localhost:56483";
    public static URL_LOGIN = "http://localhost:53341/api/User";
    public static URL_PROJECT = "http://localhost:53341/api/Project";
}