﻿import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { LoginModel } from '../login/login.model';
import { AppSetting } from '../app/app.setting';
@Injectable()
export class ProjectServices {
    public data: any;
    public token: string = "";
    public username: string = ""
    constructor(private _http: Http, private _Route: Router) {
       
        if (typeof window !== 'undefined') {

            if (localStorage.getItem('userAdmin')) {
                // logged in so return true
               
                var temp = localStorage.getItem('userAdmin') || '';
                this.data = JSON.parse(temp);
                this.token = this.data.token;
                this.username = this.data.username;
              
            }
        }
     
    }
    public list = (): Observable<any> => {
        let headers = new Headers({ 'Content-Type': 'application/json' });
        headers.append('Token', 'sdsds');
        
        let options = new RequestOptions({ headers: headers });

        return this._http.get(AppSetting.URL_PROJECT, options)
            .map((response: Response) => <any>response.json())
            .catch(response => {
                if (response.status === 401) {
                    this._Route.navigate(['Login']);
                }
                return response;
            });
    }

   
}