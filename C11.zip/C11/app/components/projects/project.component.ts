﻿import { Component,OnInit } from '@angular/core';
import { ProjectModel } from './project.model';
import { ProjectServices } from './project.services';
import { NgProgressService } from 'ng2-progressbar';
import { Pagination } from '../app/app.pagination'
import { ProjectPipe } from './project.pipe'
@Component({
    selector: 'project',
    templateUrl: './project.component.html',
    providers: [ProjectServices, Pagination],
    
   
})
export class ProjectComponent implements OnInit {
  
   
    constructor(private pService: NgProgressService, private _projectService: ProjectServices, private _paging: Pagination) {
       
    }
    public items: ProjectModel[] = [];
    ngOnInit(): void {
        this.pService.start();
      
        this._projectService.list().subscribe(data => {
            //this._paging.projectList = data;
            //this._paging.filteredItems = data;
                
            //this._paging.init();
            this.items = data;
            this.pService.done();
        },
            error => {
                if (error) {
                    alert("An Error has occured please try again after some time !");
                }
            }
        );
    }
    prevPage() {
        this._paging.prevPage();
    }
    nextPage() {
        this._paging.nextPage();
    }
    setPage(index: number) {
        this._paging.setPage(index);
    }
   
}

