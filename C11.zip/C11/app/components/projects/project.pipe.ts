﻿import { Pipe, PipeTransform } from '@angular/core';
import { ProjectModel } from './project.model';
@Pipe({ name: 'searchProject' })
export class ProjectPipe implements PipeTransform {
    transform(items: ProjectModel[], filter: ProjectModel): any {
        if (!items || !filter) {
            return items;
        }
      
        // filter items array, items which match and return true will be kept, false will be filtered out
        return items.filter(item => item.Title.indexOf(filter.Title) !== -1);
    }
}