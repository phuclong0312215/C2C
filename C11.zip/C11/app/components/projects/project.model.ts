﻿export class ProjectModel {
    public P_Id: number = 0;
    public Title: string = "";
    public Location: string = "";
    public Designer: string = "";
    public Scope: string = "";
    public Awards: string = "";
    public Images: string = "";
    public Type: string = "";
    public UserId: number = 0;
    public IsActive: number = 0;
}