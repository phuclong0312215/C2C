﻿export class ContactModel {
    public C_Id: number = 0;
    public Type: string = "";
    public BrandName: string = "";
    public Address: string = "";
    public Mobile: string = "";
    public Email: string = "";
    public Images: string = "";
    public ZipCode: string = "";
    public City: string = "";
    public UserId: number = 0;
    public IsActive: number = 0;
}