﻿import { Component, OnInit } from '@angular/core';
import { ContactModel } from './contact.model';
import { ContactServices } from './contact.services';
import { NgProgressService } from 'ng2-progressbar';
import { Pagination } from '../app/app.pagination'
@Component({
    selector: 'contact',
    templateUrl: './contact.component.html',
    providers: [ContactModel, Pagination],


})
export class ContactComponent implements OnInit {


    constructor(private pService: NgProgressService, private _contactService: ContactServices, private _paging: Pagination) {

    }
    public items: ContactModel[] = [];
    ngOnInit(): void {
        this.pService.start();

        this._contactService.list().subscribe(data => {
            //this._paging.projectList = data;
            //this._paging.filteredItems = data;

            //this._paging.init();
            this.items = data;
            this.pService.done();
        },
            error => {
                if (error) {
                    alert("An Error has occured please try again after some time !");
                }
            }
        );
    }
    prevPage() {
        this._paging.prevPage();
    }
    nextPage() {
        this._paging.nextPage();
    }
    setPage(index: number) {
        this._paging.setPage(index);
    }

}

