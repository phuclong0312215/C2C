﻿import { Component, Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';

@Injectable()
export class AuthGuardAdmin implements CanActivate {

    constructor(private router: Router) { }

    canActivate() {
       // return true;
        if (typeof window !== 'undefined') {
          
            if (localStorage.getItem('userAdmin')) {
                // logged in so return true
              
                return true;
            }
            else {
                this.router.navigate(['/Login']);
                return false;
            }
            
        }
        return false;

        //// not logged in so redirect to login page
       
    }
}