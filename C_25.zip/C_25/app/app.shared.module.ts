import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/router';

import { AppComponent } from './components/app/app.component';
import { NavMenuComponent } from './components/navmenu/navmenu.component';
import { HomeComponent } from './components/home/home.component';
import { FetchDataComponent } from './components/fetchdata/fetchdata.component';
import { CounterComponent } from './components/counter/counter.component';
import { NgProgressModule } from 'ng2-progressbar';
import { LoginComponent } from './components/login/login.component';
import { AdminComponent } from './components/admindashboard/admindashboard.component';
import { AdminLayoutComponent } from './components/layout/admin_layout/adminlayout.component';
import { ProjectComponent } from './components/projects/project.component';
import { AdminHeaderComponent } from './components/layout/header_layout/headerlayout.component';
import { AdminSidebarComponent } from './components/layout/sidebar_layout/sidebarlayout.component';
import { ProductComponent } from './components/product/product.component';
import { AuthGuardAdmin } from './components/_guards/auth.adminguard';
import { LogoutComponent } from './components/login/logout.component';
import { AddProjectComponent } from './components/projects/addproject.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { PipesModule } from 'w-ng5';
import { ProjectPipe }  from './components/projects/project.pipe';
@NgModule({
    declarations: [
        AppComponent,
        NavMenuComponent,
        CounterComponent,
        FetchDataComponent,
        HomeComponent,
        LoginComponent,
        AdminComponent,
        AdminLayoutComponent,
        ProjectComponent,
        AdminHeaderComponent,
        AdminSidebarComponent,
        ProductComponent,
        LogoutComponent,
        AddProjectComponent,
        ProjectPipe
    ],
    imports: [
        PipesModule,
        NgxPaginationModule,
        CommonModule,
        HttpModule,
        FormsModule,
        NgProgressModule,
        RouterModule.forRoot([
            { path: '', redirectTo: 'login', pathMatch: 'full' },
            {
                path: '', component: AdminLayoutComponent, children: [
                    { path: 'project', component: ProjectComponent, canActivate: [AuthGuardAdmin]},
                    { path: 'product', component: ProductComponent, canActivate: [AuthGuardAdmin] },
                    {
                        path: 'editproject/:ID', component: ProjectComponent,canActivate: [AuthGuardAdmin]
                    },
                    {
                        path: 'addproject', component: AddProjectComponent, canActivate: [AuthGuardAdmin]
                    }
                ]
            },
            { path: 'home', component: HomeComponent },
            { path: 'login', component: LoginComponent },
            { path: 'logout', component: LogoutComponent },
            { path: 'counter', component: CounterComponent },
            { path: 'fetch-data', component: FetchDataComponent },
            { path: '**', redirectTo: 'login' }
        ])
    ],
    providers: [AuthGuardAdmin]
})
export class AppModuleShared {
}
