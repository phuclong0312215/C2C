﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using C2CProject.Model;
using C2CProject.Response;
using C2CProject.Interface;
using Microsoft.Extensions.Options;
using C2CProject.Context;
using C2CProject.Util;
namespace C2CProject.Controllers
{
    [Route("api/[controller]")]
    public class UserController : Controller
    {
        private readonly IOptions<MyConfigReader> _config;
        private readonly IUserRepository _userRepository;
        private readonly ITokenRepository _tokenRepository;
        public UserController(IUserRepository userRepository,ITokenRepository tokenRepository, IOptions<MyConfigReader> config)
        {
            _config = config;
            _tokenRepository = tokenRepository;
            _userRepository = userRepository;
        }
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public LoginResponse Post([FromBody] UserItem item)
        {
            try
            {
                var loginresponse = new LoginResponse();
                if (string.IsNullOrEmpty(item.Username) || string.IsNullOrEmpty(item.Password))
                {
                    loginresponse.Username = string.Empty;
                    loginresponse.Token = string.Empty;
                    loginresponse.UserTypeID = 0;
                    return loginresponse;
                }
                item.Password = EncryptionLibrary.EncryptText(item.Password);
                var userItem = _userRepository.validateUser(item);
                if(userItem != null)
                {
                    var newToken = KeyGenerator.GenerateToken(userItem);
                    var isExistToken = _tokenRepository.isExists(userItem.U_Id);
                    _tokenRepository.deleteToken(userItem.U_Id);
                    _tokenRepository.insertToken(newToken, userItem.U_Id, Convert.ToInt32(_config.Value.TokenExpiry));
                    loginresponse.Username = item.Username;
                    loginresponse.Token = newToken;
                    loginresponse.UserTypeID = userItem.UserTypeID;
                    return loginresponse;
                }
                loginresponse.Username = string.Empty;
                loginresponse.Token = string.Empty;
                loginresponse.UserTypeID = 0;
                return loginresponse;

            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

    }
}