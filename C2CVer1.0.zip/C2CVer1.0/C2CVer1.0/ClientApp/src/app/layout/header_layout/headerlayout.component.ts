﻿import { Component } from '@angular/core'
@Component({
    selector: 'admin-header',
    templateUrl: './headerlayout.component.html'
})
export class AdminHeaderComponent {
}