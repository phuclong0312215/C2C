﻿import { Component, OnInit, Injectable } from '@angular/core'
import { Router } from '@angular/router'
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
@Component({
    template: ''
})
@Injectable()
export class LogoutComponent implements OnInit {
    constructor(private _Route: Router) {

    }
    ngOnInit() {
     
        this._Route.navigate(['login']);
    }
}

