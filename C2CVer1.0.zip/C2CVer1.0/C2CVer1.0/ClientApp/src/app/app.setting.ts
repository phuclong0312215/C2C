
export class AppSetting {
  //  public static URL = "https://localhost:44300";
  public static URL_LOGIN = "https://localhost:44300/api/User";
  public static URL_PROJECT = "https://localhost:44300/api/Project";
}
