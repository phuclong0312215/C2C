import { Component } from '@angular/core';
import { ProjectModel } from './project.model';
import { ProjectServices } from './project.services';
import { NgProgress } from '@ngx-progressbar/core';
import { Router } from '@angular/router';
@Component({
    selector: 'addproject',
    templateUrl: './addproject.component.html',
    providers: [ProjectServices]
})
export class AddProjectComponent{
  project: ProjectModel = new ProjectModel();
  constructor(private pService: NgProgress, private _projectService: ProjectServices, private _Route: Router) {

    }

   
}
