import { Component,OnInit } from '@angular/core';
import { ProjectModel } from './project.model';
import { ProjectServices } from './project.services';
import { NgProgress } from '@ngx-progressbar/core';
@Component({
    selector: 'project',
    templateUrl: './project.component.html',
    providers: [ProjectServices],
    
   
})
export class ProjectComponent implements OnInit {
  

  constructor(private pService: NgProgress, private _projectService: ProjectServices) {
       
    }
    public items: ProjectModel[] = [];
    ngOnInit(): void {
        this.pService.start();
      
        this._projectService.list().subscribe(data => {
            //this._paging.projectList = data;
            //this._paging.filteredItems = data;
                
            //this._paging.init();
          this.items = data;
          this.pService.complete();
        },
            error => {
                if (error) {
                    alert("An Error has occured please try again after some time !");
                }
            }
        );
    }
  
   
}

